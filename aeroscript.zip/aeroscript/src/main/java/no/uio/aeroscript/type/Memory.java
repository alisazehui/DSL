package no.uio.aeroscript.type;

public enum Memory {
    EXECUTION_TABLE,
    REACTIONS,
    MESSAGES,
    VARIABLES
}
