package no.uio.aeroscript.ast.expr;

public abstract class Node {
    public abstract Object evaluate();
}
